See also Core/options.lua
