# Lib: Realm Info

## [14](https://github.com/phanx-wow/LibRealmInfo/tree/14) (2019-01-01)
[Full Changelog](https://github.com/phanx-wow/LibRealmInfo/compare/13...14)

- Restore old CN data  
- Hello 2019  
- Update README  
- Update realm data  
