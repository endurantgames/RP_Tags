# RP Tags Module Template

This is a skeleton for an expansion module for rpTags.

