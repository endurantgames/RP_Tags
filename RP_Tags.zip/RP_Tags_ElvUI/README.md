# RP Tags Module Template

This is a skeleton for an expansion module for rpTags.
`RPQ.lua` does *not* need to be included with the module.
