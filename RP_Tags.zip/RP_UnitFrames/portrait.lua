  local menu = 
  { fontSize =
    { extrasmall = loc("SIZE_EXTRA_SMALL"),
      small = loc("SIZE_SMALL"),
      medium = loc("SIZE_MEDIUM"),
      large = loc("SIZE_LARGE"),
      extralarge = loc("SIZE_EXTRA_LARGE"),
    },
    portraitStyle =
    { STANDARD = "Standard 3D portrait",
      FROZEN = "Non-animated portrait",
    },

  };

