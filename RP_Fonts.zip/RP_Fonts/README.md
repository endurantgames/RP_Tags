# RP\_Fonts 

These are some selected fonts for use with RP\_Tags and related addons, as
well as a LibSharedMedia font manager.

